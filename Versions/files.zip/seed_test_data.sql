-- =============================================================================
-- TEST DATA SEED SCRIPT — run AFTER importing medicines_test_import.csv
-- via the Inventory > Bulk Import screen.
--
-- IMPORTANT — before running, check/replace if different from your setup:
--   'MAIN-01'   -> your actual branch code (branches_branch.code)
--   'cashier1'  -> your actual cashier username (accounts_user.username)
-- (Use Ctrl+F / Find-Replace in the Supabase SQL editor if they differ.)
--
-- What this creates:
--   - 5 expense categories, 4 expenses (Rent/Utilities/Salaries/Transport)
--   - 2 bank accounts (head office + branch) with realistic balances
--   - 5 customers
--   - 3 suppliers + 3 purchase orders (RECEIVED/RECEIVED/ORDERED) + payments
--     -> one fully paid, one PARTIALLY paid, one UNPAID — tests "amounts owed"
--   - 10 real POS sales spread across the last 25 days, across different
--     payment methods -> makes every analytics dashboard (trend chart, top
--     medicines, payment mix, P&L, cashier performance) show real numbers
--     immediately, with correct stock deduction + audit trail.
-- =============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- 1. Expense categories
-- ---------------------------------------------------------------------------
INSERT INTO finance_expense_category (name) VALUES
    ('Rent'), ('Utilities'), ('Salaries'), ('Transport'), ('Misc')
ON CONFLICT (name) DO NOTHING;

-- ---------------------------------------------------------------------------
-- 2. Bank accounts (manual bookkeeping)
-- ---------------------------------------------------------------------------
INSERT INTO finance_bank_account (branch_id, bank_name, account_title, account_number, iban, current_balance, is_active, created_at)
VALUES
    (NULL, 'HBL', 'Rahat Pharmacy - Head Office', 'HBL-HO-0001', '', 250000.00, TRUE, NOW()),
    ((SELECT id FROM branches_branch WHERE code = 'MAIN-01'), 'Meezan Bank', 'Rahat Pharmacy - Main Branch', 'MEZ-MAIN-0001', '', 85000.00, TRUE, NOW())
ON CONFLICT (account_number) DO NOTHING;

-- ---------------------------------------------------------------------------
-- 3. Customers
-- ---------------------------------------------------------------------------
INSERT INTO crm_customer (name, phone, email, address, home_branch_id, loyalty_points, is_active, created_at)
VALUES
    ('Ahmed Raza',   '03001234567', '', '', (SELECT id FROM branches_branch WHERE code = 'MAIN-01'), 0, TRUE, NOW()),
    ('Sara Khan',    '03011234567', '', '', (SELECT id FROM branches_branch WHERE code = 'MAIN-01'), 0, TRUE, NOW()),
    ('Bilal Ahmed',  '03021234567', '', '', (SELECT id FROM branches_branch WHERE code = 'MAIN-01'), 0, TRUE, NOW()),
    ('Ayesha Malik', '03031234567', '', '', (SELECT id FROM branches_branch WHERE code = 'MAIN-01'), 0, TRUE, NOW()),
    ('Usman Tariq',  '03041234567', '', '', (SELECT id FROM branches_branch WHERE code = 'MAIN-01'), 0, TRUE, NOW())
ON CONFLICT (phone) DO NOTHING;

-- ---------------------------------------------------------------------------
-- 4. Suppliers
-- ---------------------------------------------------------------------------
INSERT INTO suppliers_supplier (name, contact_person, phone, email, address, is_active, created_at) VALUES
    ('MediCorp Distributors',     'Kamran Ali',     '03211112222', '', '', TRUE, NOW()),
    ('National Pharma Traders',   'Waqas Iqbal',    '03221113333', '', '', TRUE, NOW()),
    ('City Medicine House',       'Faisal Mehmood', '03231114444', '', '', TRUE, NOW());

-- ---------------------------------------------------------------------------
-- 5. Purchase orders (3 scenarios: fully paid / partially paid / unpaid)
-- ---------------------------------------------------------------------------
INSERT INTO suppliers_purchase_order (branch_id, supplier_id, po_number, status, order_date, expected_date, received_date, notes, created_by_id, created_at)
VALUES
    ((SELECT id FROM branches_branch WHERE code = 'MAIN-01'),
     (SELECT id FROM suppliers_supplier WHERE name = 'MediCorp Distributors'),
     'SEED-PO-1001', 'RECEIVED', NOW() - INTERVAL '20 days', NOW() - INTERVAL '18 days', NOW() - INTERVAL '18 days', 'Seed test data', NULL, NOW() - INTERVAL '20 days'),
    ((SELECT id FROM branches_branch WHERE code = 'MAIN-01'),
     (SELECT id FROM suppliers_supplier WHERE name = 'National Pharma Traders'),
     'SEED-PO-1002', 'RECEIVED', NOW() - INTERVAL '12 days', NOW() - INTERVAL '10 days', NOW() - INTERVAL '10 days', 'Seed test data', NULL, NOW() - INTERVAL '12 days'),
    ((SELECT id FROM branches_branch WHERE code = 'MAIN-01'),
     (SELECT id FROM suppliers_supplier WHERE name = 'City Medicine House'),
     'SEED-PO-1003', 'ORDERED', NOW() - INTERVAL '3 days', NOW() + INTERVAL '4 days', NULL, 'Seed test data', NULL, NOW() - INTERVAL '3 days');

INSERT INTO suppliers_purchase_order_item (purchase_order_id, medicine_id, quantity_ordered, quantity_received, unit_cost, unit_sale_price, batch_number, expiry_date)
VALUES
    ((SELECT id FROM suppliers_purchase_order WHERE po_number = 'SEED-PO-1001'), (SELECT id FROM inventory_medicine WHERE sku = 'PAN-500'), 100, 100, 8.00, 12.00, 'PO1001-A', '2027-12-31'),
    ((SELECT id FROM suppliers_purchase_order WHERE po_number = 'SEED-PO-1001'), (SELECT id FROM inventory_medicine WHERE sku = 'DIS-01'),  50, 50,  5.00, 8.00,  'PO1001-B', '2027-12-31'),
    ((SELECT id FROM suppliers_purchase_order WHERE po_number = 'SEED-PO-1002'), (SELECT id FROM inventory_medicine WHERE sku = 'AUG-625'), 50, 50, 45.00, 65.00, 'PO1002-A', '2026-10-20'),
    ((SELECT id FROM suppliers_purchase_order WHERE po_number = 'SEED-PO-1003'), (SELECT id FROM inventory_medicine WHERE sku = 'NEX-40'),  30, 0,  30.00, 45.00, 'PO1003-A', '2027-02-28');

-- PO1001 total = 100*8 + 50*5 = 1050  -> paid in full
-- PO1002 total = 50*45 = 2250         -> paid 1500, owes 750
-- PO1003 total = 30*30 = 900          -> unpaid, owes 900
-- Expected total_due across suppliers after this script = 750 + 900 = 1650
INSERT INTO suppliers_payment (supplier_id, purchase_order_id, branch_id, bank_account_id, amount, method, reference_number, paid_on, note, created_by_id, created_at)
VALUES
    ((SELECT id FROM suppliers_supplier WHERE name = 'MediCorp Distributors'),
     (SELECT id FROM suppliers_purchase_order WHERE po_number = 'SEED-PO-1001'),
     (SELECT id FROM branches_branch WHERE code = 'MAIN-01'),
     (SELECT id FROM finance_bank_account WHERE account_number = 'MEZ-MAIN-0001'),
     1050.00, 'BANK_TRANSFER', 'PAY-1001', NOW() - INTERVAL '17 days', 'Full payment', NULL, NOW() - INTERVAL '17 days'),
    ((SELECT id FROM suppliers_supplier WHERE name = 'National Pharma Traders'),
     (SELECT id FROM suppliers_purchase_order WHERE po_number = 'SEED-PO-1002'),
     (SELECT id FROM branches_branch WHERE code = 'MAIN-01'),
     (SELECT id FROM finance_bank_account WHERE account_number = 'MEZ-MAIN-0001'),
     1500.00, 'BANK_TRANSFER', 'PAY-1002', NOW() - INTERVAL '9 days', 'Partial payment', NULL, NOW() - INTERVAL '9 days');
-- SEED-PO-1003 intentionally has NO payment -> fully outstanding payable.

-- ---------------------------------------------------------------------------
-- 6. Expenses
-- ---------------------------------------------------------------------------
INSERT INTO finance_expense (branch_id, category_id, amount, paid_from, bank_account_id, description, expense_date, created_by_id, created_at)
VALUES
    ((SELECT id FROM branches_branch WHERE code = 'MAIN-01'), (SELECT id FROM finance_expense_category WHERE name = 'Rent'),
     25000.00, 'BANK', (SELECT id FROM finance_bank_account WHERE account_number = 'MEZ-MAIN-0001'), 'Monthly shop rent', (NOW() - INTERVAL '15 days')::date, NULL, NOW() - INTERVAL '15 days'),
    ((SELECT id FROM branches_branch WHERE code = 'MAIN-01'), (SELECT id FROM finance_expense_category WHERE name = 'Utilities'),
     6500.00, 'CASH', NULL, 'Electricity bill', (NOW() - INTERVAL '10 days')::date, NULL, NOW() - INTERVAL '10 days'),
    ((SELECT id FROM branches_branch WHERE code = 'MAIN-01'), (SELECT id FROM finance_expense_category WHERE name = 'Salaries'),
     45000.00, 'BANK', (SELECT id FROM finance_bank_account WHERE account_number = 'MEZ-MAIN-0001'), 'Staff salaries', (NOW() - INTERVAL '5 days')::date, NULL, NOW() - INTERVAL '5 days'),
    ((SELECT id FROM branches_branch WHERE code = 'MAIN-01'), (SELECT id FROM finance_expense_category WHERE name = 'Transport'),
     3000.00, 'CASH', NULL, 'Delivery van fuel', (NOW() - INTERVAL '2 days')::date, NULL, NOW() - INTERVAL '2 days');

-- ---------------------------------------------------------------------------
-- 7. Realistic POS sales — 10 invoices over the last 25 days.
-- Uses a PL/pgSQL block so stock deduction, cost snapshots, line totals and
-- stock-movement audit rows are all computed correctly (mirrors exactly what
-- the /api/sales/checkout/ endpoint does), instead of hand-typing 10 invoices'
-- worth of arithmetic.
-- ---------------------------------------------------------------------------
DO $$
DECLARE
    v_branch_id BIGINT;
    v_cashier_id BIGINT;
    sales_data JSONB := '[
        {"days_ago": 25, "payment": "CASH",          "items": [{"sku":"PAN-500","qty":10},{"sku":"DIS-01","qty":5}]},
        {"days_ago": 22, "payment": "BANK_TRANSFER",  "items": [{"sku":"AUG-625","qty":2}]},
        {"days_ago": 19, "payment": "CASH",          "items": [{"sku":"RIS-20","qty":3},{"sku":"CLA-10","qty":2}]},
        {"days_ago": 16, "payment": "CASH",          "items": [{"sku":"GLU-500","qty":5}]},
        {"days_ago": 13, "payment": "CARD",          "items": [{"sku":"FLA-400","qty":4},{"sku":"ZYR-10","qty":2}]},
        {"days_ago": 10, "payment": "CASH",          "items": [{"sku":"PAN-500","qty":20}]},
        {"days_ago": 8,  "payment": "BANK_TRANSFER",  "items": [{"sku":"NEX-40","qty":1},{"sku":"CAR-3","qty":2}]},
        {"days_ago": 5,  "payment": "CASH",          "items": [{"sku":"SUR-Z","qty":3},{"sku":"PAN-CF","qty":4}]},
        {"days_ago": 3,  "payment": "CASH",          "items": [{"sku":"AMX-500","qty":2}]},
        {"days_ago": 1,  "payment": "MOBILE_WALLET",  "items": [{"sku":"BET-CR","qty":1},{"sku":"DIS-01","qty":10}]}
    ]';
    sale_rec JSONB;
    item_rec JSONB;
    v_sale_id BIGINT;
    v_batch_id BIGINT;
    v_medicine_name VARCHAR;
    v_cost NUMERIC;
    v_price NUMERIC;
    v_subtotal NUMERIC;
    v_invoice VARCHAR;
    v_created_at TIMESTAMPTZ;
    v_line_total NUMERIC;
    v_qty INTEGER;
BEGIN
    SELECT id INTO v_branch_id FROM branches_branch WHERE code = 'MAIN-01';
    IF v_branch_id IS NULL THEN
        RAISE EXCEPTION 'Branch MAIN-01 not found — edit the branch code in this script to match yours.';
    END IF;

    SELECT id INTO v_cashier_id FROM accounts_user WHERE username = 'cashier1';
    IF v_cashier_id IS NULL THEN
        RAISE EXCEPTION 'User cashier1 not found — edit the username in this script to match yours.';
    END IF;

    FOR sale_rec IN SELECT * FROM jsonb_array_elements(sales_data)
    LOOP
        v_created_at := NOW() - (sale_rec->>'days_ago')::int * INTERVAL '1 day';
        v_invoice := 'SEED-' || TO_CHAR(v_created_at, 'YYYYMMDDHH24MISS') || '-' || substr(md5(random()::text), 1, 4);
        v_subtotal := 0;

        INSERT INTO sales_sale (branch_id, invoice_number, customer_id, cashier_id, subtotal, discount_amount, tax_amount, total_amount, status, note, created_at)
        VALUES (v_branch_id, v_invoice, NULL, v_cashier_id, 0, 0, 0, 0, 'COMPLETED', 'Seed test data', v_created_at)
        RETURNING id INTO v_sale_id;

        FOR item_rec IN SELECT * FROM jsonb_array_elements(sale_rec->'items')
        LOOP
            v_qty := (item_rec->>'qty')::int;

            SELECT b.id, m.name, b.cost_price, b.sale_price
              INTO v_batch_id, v_medicine_name, v_cost, v_price
            FROM inventory_batch b
            JOIN inventory_medicine m ON m.id = b.medicine_id
            WHERE m.sku = item_rec->>'sku' AND b.branch_id = v_branch_id AND b.is_active = TRUE
            ORDER BY b.expiry_date
            LIMIT 1;

            IF v_batch_id IS NULL THEN
                RAISE EXCEPTION 'No batch found for SKU % at this branch — import medicines_test_import.csv first.', item_rec->>'sku';
            END IF;

            v_line_total := v_price * v_qty;

            INSERT INTO sales_sale_item (sale_id, batch_id, medicine_name_snapshot, quantity, unit_price, unit_cost_snapshot, discount_amount, line_total, quantity_returned)
            VALUES (v_sale_id, v_batch_id, v_medicine_name, v_qty, v_price, v_cost, 0, v_line_total, 0);

            UPDATE inventory_batch SET quantity_remaining = quantity_remaining - v_qty WHERE id = v_batch_id;

            INSERT INTO inventory_stock_movement (batch_id, branch_id, movement_type, quantity, reference, note, created_by_id, created_at)
            VALUES (v_batch_id, v_branch_id, 'SALE_OUT', -v_qty, v_invoice, 'Seed test data', v_cashier_id, v_created_at);

            v_subtotal := v_subtotal + v_line_total;
        END LOOP;

        UPDATE sales_sale SET subtotal = v_subtotal, total_amount = v_subtotal WHERE id = v_sale_id;

        INSERT INTO sales_sale_payment (sale_id, method, amount, bank_account_id, reference_number)
        VALUES (v_sale_id, sale_rec->>'payment', v_subtotal, NULL, '');
    END LOOP;
END $$;

COMMIT;
