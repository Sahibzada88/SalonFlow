import axios from 'axios'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1'

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Handle 401 errors - clear storage and redirect to login
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.clear()
      if (typeof window !== 'undefined') {
        window.location.href = '/auth/login'
      }
    }
    return Promise.reject(error)
  }
)

// NOTE ON TOKEN STORAGE: the access token is kept in localStorage, which is
// readable by any script running on the page - if this app ever has an XSS
// bug anywhere, that bug becomes a full account takeover. The properly
// secure fix is to have the backend set the session as an httpOnly cookie
// instead of returning it in the JSON body, and drop the Authorization
// header entirely in favor of `withCredentials: true`. That's a backend +
// frontend change together (not done here to avoid changing the API
// contract), but it's the recommended next step before handling real
// customer data in production.

// Auth API calls
export const authApi = {
  // FIXED: this previously posted to '/auth/register', which does not
  // exist on the backend (only '/auth/register-customer' and '/auth/staff'
  // do) - self-registration always creates a customer account, by design;
  // owner/staff accounts are provisioned separately (see backend
  // database/owner_creation_script.md and the staff creation endpoint).
  registerCustomer: (data: any) => api.post('/auth/register-customer', { ...data, role: 'customer' }),
  // Owner self-signup: creates an account with no salon attached yet: the
  // new owner is sent to /salon-setup next to create their own salon. See
  // the backend README for the accompanying `register-owner` route - it
  // deliberately does NOT accept a `role` field from the client (unlike a
  // naive generic /register endpoint would), so there's no way to
  // self-elevate into staff or take over an existing salon.
  registerOwner: (data: any) => api.post('/auth/register-owner', data),
  login: (login: string, password: string) =>
    api.post('/auth/login', new URLSearchParams({
      username: login,
      password: password,
    }), {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    }),
  // NOTE: there is no POST /auth/logout on the backend - logging out is a
  // purely client-side action (clear the stored token) since the backend
  // doesn't maintain server-side sessions beyond what Supabase Auth issues.
  getMe: () => api.get('/auth/me'),
}

export const customersApi = {
  getAll: (params?: { search?: string; limit?: number; offset?: number }) =>
    api.get('/customers', { params }),
  getOne: (id: string) =>
    api.get(`/customers/${id}`),
  create: (data: any) =>
    api.post('/customers', data),
  update: (id: string, data: any) =>
    api.put(`/customers/${id}`, data),
  delete: (id: string) =>
    api.delete(`/customers/${id}`),
}

export const appointmentsApi = {
  getAll: (params?: { start_date?: string; end_date?: string; status?: string; limit?: number }) =>
    api.get('/appointments', { params }),
  getOne: (id: string) =>
    api.get(`/appointments/${id}`),
  create: (data: any) =>
    api.post('/appointments', data),
  update: (id: string, data: any) =>
    api.put(`/appointments/${id}`, data),
  updateStatus: (id: string, status: string) =>
    api.patch(`/appointments/${id}/status`, null, { params: { status } }),
  approve: (id: string, data?: { new_date?: string; new_time?: string; reason?: string }) =>
    api.patch(`/appointments/${id}/approve`, data || {}),
  respond: (id: string, accept: boolean) =>
    api.patch(`/appointments/${id}/respond`, { accept }),
  getCustomerAppointments: () =>
    api.get('/appointments/customer/appointments'),
  getByCustomer: (customerId: string) =>
    api.get(`/appointments/by-customer/${customerId}`),
  getNotifications: () =>
    api.get('/appointments/notifications'),
  markNotificationRead: (id: string) =>
    api.patch(`/appointments/notifications/${id}/read`),
}

export const billingApi = {
  getAll: (params?: { customer_id?: string; start_date?: string; end_date?: string }) =>
    api.get('/billing/invoices', { params }),
  getOne: (id: string) =>
    api.get(`/billing/invoices/${id}`),
  create: (data: any) =>
    api.post('/billing/invoices', data),
  delete: (id: string) =>
    api.delete(`/billing/invoices/${id}`),
  getStats: (period?: string) =>
    api.get('/billing/stats', { params: { period } }),
  downloadPDF: (id: string) =>
    api.get(`/billing/invoices/${id}/pdf`, { responseType: 'blob' }),
  printPDF: (id: string) =>
    api.get(`/billing/invoices/${id}/print`, { responseType: 'blob' }),
  addPayment: (invoiceId: string, data: { amount: number; payment_method: string; payment_date?: string; notes?: string }) =>
    api.post(`/billing/invoices/${invoiceId}/payments`, data),
  getPayments: (invoiceId: string) =>
    api.get(`/billing/invoices/${invoiceId}/payments`),
}

export const staffApi = {
  getAll: () =>
    api.get('/staff'),
  create: (data: { email: string; full_name: string; phone?: string; position?: string; permissions?: Record<string, boolean> }) =>
    api.post('/auth/staff', data),
  delete: (id: string) =>
    api.delete(`/staff/${id}`),
}

export const salonsApi = {
  setup: (data: any) =>
    api.post('/salons/setup', data),
  getMine: () =>
    api.get('/salons/my-salon'),
}

export const dashboardApi = {
  getStats: () =>
    api.get('/dashboard/stats'),
}
