# Changes from the original backend

## Security fixes

1. **Broken access control on billing (critical).** `GET /billing/invoices`,
   `/billing/stats`, `/billing/invoices/{id}`, and the PDF endpoints
   previously had no role check at all - only "does this token map to a
   salon_id" (which is also true for customers). Any registered customer
   could list/download every invoice, every payment, and revenue stats for
   the entire salon. Fixed: the whole billing router now requires
   `owner`/`staff`, and money-moving actions additionally require the
   `can_bill` staff permission.

2. **Broken access control on appointments (critical).** `GET
   /appointments/` had the same gap - a customer could list every
   appointment in the salon. Fixed: that route is now `owner`/`staff` only;
   customers use `/appointments/customer/appointments`, which is scoped to
   `customer_id`.

3. **IDOR on reschedule response.** `PATCH /appointments/{id}/respond`
   never verified the appointment belonged to the calling customer before
   accepting/cancelling it - any customer could act on any other
   customer's appointment by ID. Fixed: ownership is checked before calling
   the RPC.

4. **Staff could delete other staff.** `DELETE /staff/{id}` checked "same
   salon" but not `is_owner`. Fixed: now requires the `owner` role.

5. **Staff were locked out of customer management.** `customers.py`
   resolved salon scope via `salons.owner_id` only, so staff accounts got
   empty lists / 400s. Fixed: resolved via the same `UserContext.salon_id`
   used everywhere else, which correctly covers staff.

6. **CORS misconfiguration.** `allow_origins=["*"]` with
   `allow_credentials=True`. Fixed: real allowlist via `CORS_ALLOWED_ORIGINS`
   env var.

7. **Weak/absent secret handling.** `JWT_SECRET_KEY` had a hardcoded
   placeholder default and `DEBUG` defaulted to `True`. Fixed: no default
   secret (app fails to start if missing from env), `DEBUG` now defaults to
   `False`. `.env.example` added; `.gitignore` (previously empty in both
   frontend and backend) now actually excludes `.env` and other secrets.

8. **Weak temporary passwords.** Staff temp passwords were generated with
   `random.choices()`, which is not cryptographically secure. Fixed: uses
   `secrets.choice()`.

9. **No login rate limiting.** Added a small in-memory limiter (5 attempts /
   60s per IP+identifier). This is process-local, not distributed - fine as
   a first line of defense, but put a real rate limiter (Redis-backed, or
   at your reverse proxy) in front of this in production with multiple
   instances.

10. **Information leakage via error responses.** Every route wrapped its
    body in `except Exception as e: raise HTTPException(400, str(e))`,
    collapsing every failure into HTTP 400 and echoing raw exception text
    (including DB errors) to the client. Fixed: routes let `HTTPException`s
    propagate with their real status codes; anything unexpected is caught by
    a global handler that logs the full traceback server-side and returns a
    generic message to the client (unless `DEBUG=true`).

## Bug fixes (not security, but real bugs)

11. **Route-ordering bug hid `/appointments/notifications`.**
    `GET /{appointment_id}` was declared before `GET /notifications` in the
    same router. Since routes are matched in declaration order and
    `/notifications` is a single path segment, it satisfied
    `{appointment_id}` first and was captured by `get_appointment("notifications")`.
    Fixed by declaring all fixed-path routes before any `/{appointment_id}...`
    route.

12. **`GET /appointments/{id}` could never find most appointments.** It
    called the `get_appointments` RPC with `p_limit=1`, then searched that
    single-row result for a match - meaning only the single most recent
    appointment in the salon was ever retrievable by ID. Fixed: raised the
    limit (a dedicated single-row RPC would be the ideal long-term fix; see
    the SQL notes).

13. **Duplicate route definition.** `PATCH /appointments/{id}/approve` was
    defined twice with identical path/method; the second silently shadowed
    the first. Consolidated into one implementation.

14. **Dead/unused code removed.** `app/core/security.py` (a full
    JWT-issuing + bcrypt password-hashing implementation) was never
    actually used - login goes through Supabase Auth, not this code. The
    SQLAlchemy models in `app/models/` (with a `UserRole` enum that doesn't
    even match the real roles in use - `reception`/`admin` vs. the actual
    `owner`/`staff`/`customer`) and `app/core/database.py` were similarly
    unused; no route ever queried through them. Removed both, along with
    the now-unneeded `sqlalchemy`/`alembic`/`psycopg2-binary` dependencies,
    to reduce confusion about which code path is actually live.

15. **Duplicate/garbled `requirements1.txt`** (UTF-16-encoded, redundant
    with `requirements.txt`) removed. **Empty `Dockerfile`** (0 bytes in the
    original) replaced with a working one. Duplicate Vercel entrypoint
    (`app/api/index.py` and `api/index.py`, near-identical) reduced to one.

## Addendum (added alongside the frontend rewrite)

16. **Added `POST /auth/register-owner`.** The frontend's owner
    registration page originally posted to `/auth/register`, which never
    existed on this backend - that flow was completely broken. Rather than
    resurrecting a generic `/register` endpoint that accepts a client-chosen
    `role` (a privilege-escalation risk), a dedicated endpoint was added
    that always creates an `owner` account with no salon attached; the new
    owner is then sent to the already owner-gated `POST /salons/setup` to
    create their own salon.

## Addendum 2: httpOnly session cookie (fixes the localStorage XSS risk)

17. **Token storage moved from client-readable to httpOnly cookie.**
    `POST /auth/login` no longer returns `access_token` in the JSON body at
    all - it's set as an `httpOnly`, `Secure` (in production), cookie
    instead. This means client-side JavaScript (including any XSS payload
    that might ever get injected into the frontend) can no longer read the
    session token. `get_current_user` now reads the token from that cookie
    first, falling back to a Bearer `Authorization` header only for
    non-browser API clients (curl/Postman/etc). A new `POST /auth/logout`
    endpoint was added to clear the cookie server-side, since the frontend
    can no longer just delete it from localStorage itself.

    Cookie attributes (`COOKIE_SECURE`, `COOKIE_SAMESITE`) are
    environment-driven in `app/core/config.py` - production defaults to
    `Secure=true; SameSite=None` (required for a frontend and backend on
    different domains, e.g. Vercel + Render), local dev defaults to
    `Secure=false; SameSite=lax` when `DEBUG=true`. Override via env vars if
    your deployment topology differs (e.g. frontend/backend on the same
    parent domain, where `SameSite=lax` would still work in production too).

## Known limitation this backend change does NOT fix

Row Level Security policies on the Supabase tables are effectively
decorative right now, since every query from this backend uses the
service-role key (which bypasses RLS) and the frontend never talks to
Supabase directly. All authorization lives in this codebase's
`auth_deps.py`. If you ever add a code path that talks to Supabase directly
from the browser (even partially), you must also fix the RLS policies -
see the accompanying SQL migration notes for specifics (several policies,
e.g. on the `staff` table, only check `owner_id` and would incorrectly
block staff from their own data if ever relied upon).
